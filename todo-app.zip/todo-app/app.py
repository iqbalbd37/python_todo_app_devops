from flask import Flask, render_template, request, redirect, url_for

app = Flask(__name__)

# In-memory list (resets when server restarts)
todos = []


@app.route("/")
def index():
    # Pagination logic
    page = int(request.args.get("page", 1))
    per_page = 5

    total_tasks = len(todos)
    total_pages = (total_tasks // per_page) + (1 if total_tasks % per_page else 0)

    start = (page - 1) * per_page
    end = start + per_page
    current_tasks = todos[start:end]

    return render_template(
        "index.html",
        todos=current_tasks,
        page=page,
        pages=total_pages
    )


@app.route("/add", methods=["POST"])
def add_task():
    task = request.form.get("task")
    if task:
        todos.append(task)
    return redirect(url_for("index"))


@app.route("/delete/<int:index>")
def delete_task(index):
    if 0 <= index < len(todos):
        todos.pop(index)
    return redirect(url_for("index"))


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)

