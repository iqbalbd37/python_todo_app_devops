# To-Do App (Flask 3.x)

## Overview
This is a simple To-Do web application built using Flask 3.x, HTML, CSS and Jinja2 templating.
It includes:
- Task creation
- Task deletion
- Pagination support
- Docker support for easy deployment

## Tech Stack
- Python 3.11
- Flask 3.0.3
- Werkzeug 3.0.3
- HTML5, CSS3
- Docker

## Features
1. Add new tasks
2. Delete existing tasks
3. Pagination (5 tasks per page)
4. Lightweight and easy to deploy

## Installation

### Local

